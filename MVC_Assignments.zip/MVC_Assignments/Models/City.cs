﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyFinal.Models
{
    public class City
    {
        public int cityId { get; set; }
        public string cityName { get; set; }

    }
}